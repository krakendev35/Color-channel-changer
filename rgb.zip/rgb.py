# https://www.youtube.com/watch?v=OSjOCwjEu9w

from PIL import Image
im = Image.open('image.jpg').convert('RGB') #Change image.jpg to your existing image

r, g, b = im.split()

r = r.point(lambda i: i * 1)                #if you want to incerase a channel intensity incerase the value (i.e :2.4)
g = g.point(lambda i: i * 1)                #if you want to decrease a channel intensity decrease the value (i.e :0.4)
b = b.point(lambda i: i * 1)

result = Image.merge('RGB', (r, g, b))

result.save('result.png')                   #you can change the output name and format just changing the result.png
